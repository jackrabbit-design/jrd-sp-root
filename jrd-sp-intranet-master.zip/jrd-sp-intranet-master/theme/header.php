<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
<!-- DEVELOPER NOTE: MAKE SURE THIS IS AFTER <meta charset="utf-8" />
                                    +        
                                  ++++       
                                 ++++++      
                                ++++++++     
                               ++++++++++    
                              ++++++++++++   
                              ++++++++++++,  
                             ++++++++++++++  
                             ++++++++++++++, 
                            ,+++++++++++++++ 
            +??????????????333++++++++++++++ 
        +++++++++++++I3333333333++++++++++++ 
      ++++++++++++733333333333333+++++++++++ 
     +++++++++++333333333333333333++++++++++ 
     +++++++++   333333333333333333+++++++++ 
     ++++++++     33333333333333333+++++++++ 
     ++++++        33333333333333333+++++++  
     +++++          3333333333333333+++++++  
     ++++             33333333333333++++++   
     +++                3333333333333++++    
      ++                  33333333333+++     
                            333333337++      
                               33333++       
                                  33+        

-->
  <meta name="MSSmartTagsPreventParsing" content="true" /><!--[if lte IE 9]><meta http-equiv="X-UA-Compatible" content="IE=Edge"/><![endif]-->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
  <title><?php wp_title( '|', true, 'right' ); ?></title>
  <link type="text/css" rel="stylesheet" media="all" href="<? bloginfo('url') ?>/ui/css/style.css" />
  <link type="text/plain" rel="author" href="<? bloginfo('url') ?>/authors.txt" />
  <link type="image/x-icon" rel="shortcut icon" href="<? bloginfo('url') ?>/favicon.png" />
  <script src="<? bloginfo('url') ?>/ui/js/modernizr.js"></script>
  <script src="<? bloginfo('url') ?>/ui/js/jquery.js" type="text/javascript"></script>
  <?php wp_head(); ?>
</head>

<body <? body_class() ?>>
    <!--[if lte IE 7]><iframe src="unsupported.html" frameborder="0" scrolling="no" id="no_ie6"></iframe><![endif]-->
        <div class="wrap">
        <div id="header">
            <div id="topmenu">
                <div class="logomargins">
                    <a href="<? bloginfo('url') ?>" class="logoimg">
                        <img src="<? bloginfo('url') ?>/ui/images/logo.jpg" class="logoimg" alt="<? bloginfo('name') ?>">
                    </a>
                </div>
                <div id="usermenu">
                    <ul class"usermenuitems">
                        <li><a href="#">Hello, Jude</a></li>
                        <li><a href="#">Logout</a></li>
                        <li id='headsearch' class='headsearch' >
                                <input name='searchhead' id='headsearch' type='text' placeholder="" value='' />
                        </li>
                    </ul>
                    
                </div>
                <div id="headmenu">
                    
                    <a class="mobile nav-toggle icon-menu"></a>
                    <div id="nav-container">
                    <?php
                      $mob = '';
                      $mob .= '<div class="nav">';
                      $mob .= $top;;
                      $mob .= get_search_form(false);
                      $mob .= '</div>';
      
                      wp_nav_menu( array(
                          'theme_location' => 'main-menu', 
                          'container' => '', 
                          'menu_class' => 
                          'nav', 
                          'menu_id' => '', 
                          'depth' => 2,
                          'items_wrap' => ''
                      ));
                    ?>
                    
                </div>
            </div>
        </div>
        <div class="clear"></div>
        <div id="homebanner">
            <div class="homebannerwrap">
            <div class="homebannertext">
                <h6>We are client-focused, hard working, integrity-filled, loyal, and professional.</h6>
            </div>
            <div class="homebannerreadmore">
                <a href="#" class="readmorehome">Read More</a>
            </div> 
            </div>           
        </div>
        <div id="secondarymenu">
            <div class="secondarynav">
                <ul>
                    <li><a href="#"  class="icon-bulletlist">Forms &amp; Benefits</a></li>
                    <li><a href="#" class="icon-imported-layers">Company Calendar</a></li>
                    <li><a href="#" class="icon-trisplotch">Employee Exchange</a></li>
                    <li><a href="#" class="icon-courthouse">Policies &amp; Procedures</a></li>
                </ul>
            </div>
        </div>
        <div id="contentwrap">