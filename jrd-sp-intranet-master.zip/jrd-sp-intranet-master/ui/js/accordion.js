
    
    $('.nav-toggle').click(function(){
                $('#nav-container').toggleClass('show');
    });
    
    // Toggled label
    //var tt = "Close";
    //$('.nav-toggle').click(function(){
  //     var tn = $(this).text();
  //     $(this).toggleClass('close').text(tt);
  //     tt = tn;
 //      $('#mobile-menu').slideToggle();
 //   });
    
    
    
   // $('.menu-item-has-children span').click(function(){
   //        $(this).parent().toggleClass('open');
   //        $(this).parent().parent().toggleClass('open');
   //        $(this).parent().next('ul').slideToggle(200);
   // });
